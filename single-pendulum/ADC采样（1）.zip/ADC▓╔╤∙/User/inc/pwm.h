#ifndef __PWM_H
#define __PWM_H	






#include "stm32f10x.h"

void PWM_Init(int arr,int ccr);



#endif